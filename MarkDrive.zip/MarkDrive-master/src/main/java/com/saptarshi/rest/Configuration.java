package com.saptarshi.rest;

public class Configuration {
	
	static final String USERNAME = "admin";
	static final String PASSWORD = "admin";
	static final String CONNECTIONURL = "localhost";
	static final int PORT = 8000; 
	

}
